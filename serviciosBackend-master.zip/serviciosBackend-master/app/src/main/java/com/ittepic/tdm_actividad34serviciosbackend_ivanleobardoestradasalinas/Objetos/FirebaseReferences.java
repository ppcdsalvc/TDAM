package com.ittepic.tdm_actividad34serviciosbackend_ivanleobardoestradasalinas.Objetos;

public class FirebaseReferences {
    final public static String ALUMNO_REFERENCE = "alumno";
}
